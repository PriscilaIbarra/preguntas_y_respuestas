import React, { useState } from 'react';
import { Button, Container, Typography, Card, CardContent, Box, Grid } from '@mui/material';

// Array of questions
const questions = [
  {
    question: "What is React?",
    options: ["A library for building UIs", "A programming language", "A database", "A framework for backend"],
    answer: "A library for building UIs"
  },
  {
    question: "What does JSX stand for?",
    options: ["JavaScript Extension", "JavaScript XML", "JavaScript X-ray", "None of the above"],
    answer: "JavaScript XML"
  },
  {
    question: "What hook is used to manage state in a functional component?",
    options: ["useState", "useEffect", "useContext", "useReducer"],
    answer: "useState"
  },
  {
    question: "Which of these is used to create a component in React?",
    options: ["class Component", "function Component", "Both A and B", "None of the above"],
    answer: "Both A and B"
  }
];

function App() {
  // State variables
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [score, setScore] = useState(0);
  const [selectedOption, setSelectedOption] = useState("");

  const handleOptionClick = (option) => {
    if (option === questions[currentQuestion].answer) {
      setScore(score + 1);
    }
    setSelectedOption(option);
  };

  const handleNext = () => {
    if (currentQuestion < questions.length - 1) {
      setCurrentQuestion(currentQuestion + 1);
      setSelectedOption(""); // Clear selected option
    }
  };

  const handleFinish = () => {
    alert(`Your score is: ${score} / ${questions.length}`);
  };

  return (
    <Container maxWidth="sm" sx={{ mt: 4 }}>
      <Typography variant="h3" gutterBottom align="center" color="primary">
        React Quiz
      </Typography>

      <Card variant="outlined" sx={{ mb: 4 }}>
        <CardContent>
          <Typography variant="h5">{questions[currentQuestion].question}</Typography>
          <Box mt={2}>
            <Grid container spacing={2}>
              {questions[currentQuestion].options.map((option, index) => (
                <Grid item xs={12} sm={6} key={index}>
                  <Button
                    variant="contained"
                    fullWidth
                    onClick={() => handleOptionClick(option)}
                    color={selectedOption === option ? (option === questions[currentQuestion].answer ? 'success' : 'error') : 'primary'}
                    sx={{ mb: 2 }}
                  >
                    {option}
                  </Button>
                </Grid>
              ))}
            </Grid>
          </Box>
        </CardContent>
      </Card>

      <Box textAlign="center">
        {currentQuestion < questions.length - 1 ? (
          <Button variant="contained" onClick={handleNext} sx={{ mt: 2 }}>
            Next Question
          </Button>
        ) : (
          <Button variant="contained" onClick={handleFinish} sx={{ mt: 2 }}>
            Finish Quiz
          </Button>
        )}
      </Box>

      <Box textAlign="center" sx={{ mt: 4 }}>
        <Typography variant="h6">
          Score: {score}
        </Typography>
      </Box>
    </Container>
  );
}

export default App;
